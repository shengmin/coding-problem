It only generates common English words, you can add more to the "words.txt" file, one word per line in lowercase (Pleast do not move or change the name of the file)
It might take a few seconds to finish if number of letters is 7 or 8 since it's doing naive exhaustive search without any branch pruning or optimizations

One example usage:
- Enter "7" into "Number of Letters" box
- Enter "effhhhilrssu" into "Available Letters" box
- Hit "Generate"
- Wait for a second or two for a list of words to appear in the "Possible Words" box